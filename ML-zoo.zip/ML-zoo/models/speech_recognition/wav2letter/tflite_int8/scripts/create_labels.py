# Copyright (C) 2021 Arm Limited or its affiliates. All rights reserved.
#
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the License); you may
# not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

def get_label_dict():
    alphabet = "abcdefghijklmnopqrstuvwxyz' @"
    return [c for c in alphabet]

if __name__ == "__main__":
    labels = get_label_dict()

    with open("labelmappings.txt", "w") as f:
        for l in labels:
            f.write('{}\n'.format(l))
